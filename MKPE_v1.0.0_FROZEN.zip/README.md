# Morse-Kirby Provenance Engine (MKPE) v1.0.0

**The canonical provenance engine for creative and computational processes.**

## Core Principle

> *"Every verified object carries its own truth."*

## Lineage

- **ADNA** (Architectural DNA) → Structural mapping
- **CDNA** (Component DNA) → Granular component identity  
- **MKPE** → Cryptographic provenance chain

## What is MKPE?

MKPE is a cryptographic provenance system that provides verifiable proof of authenticity, authorship, and integrity for any digital artifact. It combines:

- **Ed25519 digital signatures** for authentication
- **SHA-256 content hashing** for integrity
- **Recursive proof bundling** for complex structures
- **Self-verifying manifests** for transparency
- **.mkpe archive format** for portability

## Directory Structure

```
C:\mkpe\
├── core/                  # Rust core library (morse_kirby_core)
│   ├── src/
│   │   ├── lib.rs        # Public API
│   │   ├── crypto.rs     # Ed25519 + SHA-256
│   │   ├── proof.rs      # Proof generation/verification
│   │   ├── manifest.rs   # Self-verifying manifests
│   │   ├── bundle.rs     # .mkpe binary format
│   │   ├── cdna.rs       # C-DNA schema support
│   │   └── error.rs      # Error types
│   └── Cargo.toml
├── cli/                   # Command-line tool
│   ├── src/main.rs       # MKPE CLI
│   └── Cargo.toml
├── bindings/              # Language bindings
│   ├── cpp/              # C++ API (future)
│   ├── python/           # Python API (future)
│   └── typescript/       # TypeScript API (future)
├── tools/                 # Integration tools
│   ├── Invoke-MKPE.ps1   # PowerShell wrapper
│   └── Install-MKPE.ps1  # System installer
├── schemas/               # JSON schemas
├── docs/                  # Documentation
├── examples/              # Example usage
├── tests/                 # Integration tests
└── logs/                  # Operation logs
```

## Quick Start

### 1. Build MKPE

```powershell
# Build core library
cd C:\mkpe\core
cargo build --release

# Build CLI tool
cd C:\mkpe\cli
cargo build --release
```

### 2. Generate a Keypair

```powershell
cd C:\mkpe\examples
C:\mkpe\cli\target\release\mkpe.exe keygen
```

This creates:
- `mkpe_private.key` - Keep this secret!
- `mkpe_public.key` - Share for verification

### 3. Sign a File

```powershell
C:\mkpe\cli\target\release\mkpe.exe sign myfile.txt -k mkpe_private.key
```

Creates `myfile.mkpe` - a cryptographically signed proof bundle.

### 4. Verify Integrity

```powershell
C:\mkpe\cli\target\release\mkpe.exe verify myfile.mkpe -d
```

### 5. Bundle a Directory

```powershell
C:\mkpe\cli\target\release\mkpe.exe bundle myproject\ -k mkpe_private.key -o myproject.mkpe
```

## .mkpe File Format v1.0

The `.mkpe` format uses a structured binary layout:

### Header (32 bytes)

| Offset | Size | Field          | Description                     |
|--------|------|----------------|---------------------------------|
| 0x00   | 4 B  | Magic          | ASCII "MKPE" (0x4D4B5045)      |
| 0x04   | 1 B  | Version        | Format version (0x01)           |
| 0x05   | 1 B  | Flags          | 0x01=encrypted, 0x02=compressed |
| 0x06   | 8 B  | Manifest Size  | Little-endian u64               |
| 0x0E   | 8 B  | Proof Size     | Little-endian u64               |
| 0x16   | 8 B  | Signature Size | Little-endian u64               |
| 0x1E   | 2 B  | Reserved       | Future use (0x0000)             |

### Section 1: Manifest (JSON, plaintext)

Human-readable metadata:

```json
{
  "schema_version": "1.0.0",
  "engine_version": "1.0.0-mkpe",
  "manifest_id": "uuid",
  "system_fingerprint": {
    "user": "username",
    "platform": "Windows",
    "hostname": "machine-name",
    "process_id": 12345,
    "mkpe_version": "1.0.0-mkpe",
    "timestamp": "2025-10-08T15:00:00Z"
  },
  "bundle_root_hash": "sha256...",
  "proof_count": 5,
  "sealed_timestamp": "2025-10-08T15:00:00Z",
  "verifier_public_key": "base64...",
  "signature": "base64...",
  "metadata": {}
}
```

### Section 2: Proof Data (binary)

Merkle tree of file hashes:

```
[ u32 count ]          # 4 bytes: number of proofs
[ 32B hash_1 ]         # SHA-256 binary hash
[ 32B hash_2 ]
...
```

### Section 3: Signature Block (binary, 96 bytes)

```
[ 32B public_key ]     # Ed25519 public key
[ 64B signature ]      # Ed25519 signature over SHA256(manifest || proof_data)
```

### Footer (8 bytes)

| Offset | Size | Field   | Description                      |
|--------|------|---------|----------------------------------|
| EOF-8  | 4 B  | Magic   | ASCII "EPKM" (reverse of MKPE)   |
| EOF-4  | 4 B  | CRC32   | Checksum for corruption detection|

## CLI Commands

### `mkpe keygen`
Generate a new Ed25519 keypair

```powershell
mkpe keygen -o <output_dir>
```

### `mkpe sign`
Sign a file or directory

```powershell
mkpe sign <path> -k <private_key> [-o <output.mkpe>]
```

### `mkpe verify`
Verify a .mkpe bundle

```powershell
mkpe verify <path.mkpe> [-d]  # -d for detailed output
```

### `mkpe bundle`
Create a proof bundle from a directory

```powershell
mkpe bundle <dir> -k <private_key> -o <output.mkpe>
```

### `mkpe inspect`
Inspect a .mkpe file

```powershell
mkpe inspect <path.mkpe> [-e <manifest.json>]  # -e to export manifest
```

### `mkpe hash`
Calculate SHA-256 hash of a file

```powershell
mkpe hash <path>
```

### `mkpe validate-cdna`
Validate a C-DNA schema file

```powershell
mkpe validate-cdna <schema.cdna.json> [--proof] [-k <private_key>]
```

### `mkpe version`
Show version and build information

```powershell
mkpe version
```

## C-DNA Support

MKPE includes native support for Component DNA (C-DNA) schemas version 3.0.0:

```json
{
  "c_dna_version": "3.0.0",
  "program_id": "my.program.v1",
  "intent": "Program purpose",
  "nodes": [...],
  "edges": [...]
}
```

You can create cryptographic proofs for C-DNA schemas:

```powershell
mkpe validate-cdna myschema.cdna.json --proof -k mkpe_private.key
```

## PowerShell Integration

Use the PowerShell wrapper for easier integration:

```powershell
# Import the wrapper
. C:\mkpe\tools\Invoke-MKPE.ps1

# Use simplified commands
Invoke-MKPE -Command keygen -Output C:\keys
Invoke-MKPE -Command sign -Path myfile.txt -Key C:\keys\mkpe_private.key
Invoke-MKPE -Command verify -Path myfile.mkpe -Detailed
```

## System Installation

Install MKPE to `C:\Kalyx\MKPE\v1.0.0`:

```powershell
cd C:\mkpe\tools
.\Install-MKPE.ps1
```

This will:
- Copy binaries to installation directory
- Register the .mkpe file extension (requires Administrator)
- Generate canonical manifest with hash
- Run validation tests
- Create logs at `C:\Kalyx\LOGS\MKPE_VALIDATION.txt`

## API Usage (Rust)

```rust
use morse_kirby_core::*;

// Generate keypair
let keypair = generate_keypair();

// Create proof for a file
let proof = create_proof_item("myfile.txt", &keypair)?;

// Create proof bundle from directory
let proofs = create_recursive_proofs("mydir/", &keypair)?;
let bundle = create_proof_bundle(proofs, &keypair, None)?;

// Create manifest
let mut manifest = Manifest::new(
    bundle.root_hash.clone(),
    bundle.proofs.len(),
    keypair.public_key.clone(),
    None,
);
manifest.sign(&keypair)?;

// Create .mkpe archive
let archive = MkpeArchive::new(manifest, vec![bundle]);
archive.save("output.mkpe")?;

// Load and verify
let loaded = MkpeArchive::load("output.mkpe")?;
let is_valid = loaded.verify()?;
```

## Security Model

### Cryptographic Foundation
- **SHA-256** for content integrity
- **Ed25519** for digital signatures
- **Merkle trees** for efficient verification
- **CRC32** for corruption detection

### Trust Model
- Local keypair generation (no cloud dependencies)
- Chain integrity via linked signatures
- Fail-closed security (operations fail if provenance fails)
- Complete audit trail

### Threat Protection
- **Tamper Evidence**: File modifications break verification
- **Replay Protection**: Timestamps and chain linkage
- **Identity Assurance**: Cryptographic proof of authorship
- **Non-repudiation**: Signatures cannot be forged

## Use Cases

### Software Development
- Code verification and authorship proof
- Build integrity attestation
- Release signing

### Creative Professionals
- Sign manuscripts, articles, creative works
- Prove authenticity of digital art
- Verify composition and production provenance

### Business Applications
- Document integrity (legal, contracts, reports)
- Workflow automation with audit trails
- Compliance and regulatory requirements

### Research & Academia
- Data integrity for research datasets
- Publication and academic papers
- Reproducible research verification

## Version Information

- **MKPE Version**: 1.0.0-mkpe
- **Schema Version**: 1.0.0
- **Format Version**: v1.0 (binary)
- **C-DNA Version**: 3.0.0

## License

Proprietary - Morse-Kirby Provenance Engine

## Support

For issues or questions about MKPE, please refer to the documentation in `C:\mkpe\docs\`.

---

**Remember**: Your private key is your digital identity. Keep it secure!

